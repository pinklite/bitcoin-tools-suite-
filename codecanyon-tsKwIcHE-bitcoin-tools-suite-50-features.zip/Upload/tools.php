<?php
// require the website config file.
require_once('includes/config.php');

// set the tool and response variables.
if ($website['tools'][$_REQUEST['tool']]['type'] == 'info') {
    $tool     = $website['tools'][$_REQUEST['tool']];
    $response = $tool['class']::response($_REQUEST);
} elseif (isset($_REQUEST['tool']) && isset($website['tools'][$_REQUEST['tool']])) {
    $tool     = $website['tools'][$_REQUEST['tool']];
    $response = (isset($_REQUEST['submit']) ? $tool['class']::response($_REQUEST) : false);
} else {
    header('HTTP/1.1 301 Moved Permanently');
    header('location: ' . $website['url']);
    exit;
}

$meta = array('title' => $tool['name'], 'description' => $tool['description']);
require_once('includes/templates/' . $website['template'] . '/header.php');

echo '<div class="hero"><div class="container"><h1>' . $tool['name'] . '</h1><p>' . $tool['description'] . '</p></div></div><div class="container tool-content">';
require_once($tool['directory'] . '/tool.html.php');
echo '</div>';

?>

<div class="container">

      <?php // list the website tools for the selected category. ?>
<div class="row">
    <h3>Similar tools</h3><hr/>
      <?php $i = 0;
      foreach ( $website['tools'] as $tools ):?>
      <?php if($tools['category'] == $tool['category'] && $i < 2) { ?>
         <div class="col-md-6">
         <div class="tool">
<div class="icon-feature">
                     <div class="icon">
                        <i class="<?php echo $tools['icon'];?>"></i>
                     </div>
                  </div>
		      <div class="tool-meta"><a href="<?php echo $tools['urls']['tool'];?>"><h4><?php echo $tools['name'];?></h4></a>
		      <p><?php echo $tools['description'];?></p>
		      <a href="<?php echo $tools['urls']['category'];?>" class="label label-default"><?php echo $tools['category'];?></a></div>
		   </div>
		   </div>
      <?php $i++; } endforeach;?>
</div>
</div>
   </div>
<?php

require_once('includes/templates/' . $website['template'] . '/footer.php');


?>
