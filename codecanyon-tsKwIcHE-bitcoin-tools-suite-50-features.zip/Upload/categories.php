<?php
// require the website config file.
require_once('includes/config.php');

// set the category variable.
if ( isset($_REQUEST['category']) && isset($website['categories'][$_REQUEST['category']]) ) {
   $category = $website['categories'][$_REQUEST['category']];
}
else {
   header('HTTP/1.1 301 Moved Permanently');
   header('location: ' . $website['url']);
   exit;
}
$meta = array('title' => $website['name'], 'description' => $website['description']);
require_once('includes/templates/' . $website['template'] . '/header.php');
?>
<div class="hero">
<div class="container">
<h1><?php echo ucfirst($category['name']); ?></h1>
<p>Browse tools in the <?php echo ucfirst($category['name']); ?> category</p>

</div>
</div><br/>
<div class="container">
      <?php // list the website tools for the selected category. ?>
<div class="row">
      <?php foreach ( $website['tools'] as $tool ):?>
      <?php if($tool['category'] == $category['name']) { ?>
         <div class="col-md-6">
         <div class="tool">
<div class="icon-feature">
                     <div class="icon">
                        <i class="<?php echo $tool['icon'];?>"></i>
                     </div>
                  </div>
		      <div class="tool-meta"><a href="<?php echo $tool['urls']['tool'];?>"><h4><?php echo $tool['name'];?></h4></a>
		      <p><?php echo $tool['description'];?></p>
		      <a href="<?php echo $tool['urls']['category'];?>" class="label label-default"><?php echo $tool['category'];?></a></div>
		   </div>
		   </div>
      <?php } endforeach;?>
</div>

<?
require_once('includes/templates/' . $website['template'] . '/footer.php');
?>
