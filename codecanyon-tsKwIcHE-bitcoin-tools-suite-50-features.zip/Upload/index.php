<?php
require_once('includes/config.php');
$meta = array('title' => $website['name'], 'description' => $website['description']);
require_once('includes/templates/' . $website['template'] . '/header.php');
$tickers = website_tools::cache_json($website['cache_time']);
?>
<div class="hero">
<div class="container">
<h1>Bitcoin Tools Suite</h1>
<p>Powerful bitcoin and cryptocurrency tools & tickers.</p>

</div>
</div>
<div class="ticker-title">
  <div class="container">
    <h4>Bitcoin Prices <a href="#" class="btn btn-link" data-toggle="collapse" data-target="#tickers" aria-expanded="false" aria-controls="tickers">(Show All?)</a></h4>
  </div>
</div>
<div class="tickers">
  <div class="container">
    <div class="row">
<?php
$i = '0';
foreach($tickers as $key => $value) {
  echo '<div class="col-md-2"><div class="ticker row"><div class="col-md-4">' . $key . '</div><div class="col-md-8">' . number_format($value, 2) . '</div></div></div>';
  if($i == '5') {
    echo '<div id="tickers" class="collapse">';
  }
  $i++;
} ?>
</div>
</div>
  </div>
</div>
<div class="container">

<?php foreach ( $website['categories'] as $cat ):?>
<div class="category"><h2><?php echo ucfirst($cat['name']);?> <a href="<?php echo 'categories/' . $cat['slug']; ?>" class="btn btn-default btn-sm btn-round pull-right">View Category</a></h2></div>
<div class="row">
      <?php foreach ( $website['tools'] as $tool ):?>
      <?php if($tool['category'] == $cat['name']) { ?>
         <div class="col-md-6">
         <div class="tool">
         <div class="icon-feature">
                     <div class="icon">
                        <i class="<?php echo $tool['icon'];?>"></i>
                     </div>
                  </div>
		      <div class="tool-meta"><a href="<?php echo $tool['urls']['tool'];?>"><h4><?php echo $tool['name'];?></h4></a>
		      <p><?php echo $tool['description'];?></p>
		      <a href="<?php echo $tool['urls']['category'];?>" class="label label-default"><?php echo ucfirst($tool['category']);?></a></div>
		   </div>
		   </div>
      <?php } endforeach;?>
</div>
      <?php endforeach;?>

</div>
<?
require_once('includes/templates/' . $website['template'] . '/footer.php');
?>
