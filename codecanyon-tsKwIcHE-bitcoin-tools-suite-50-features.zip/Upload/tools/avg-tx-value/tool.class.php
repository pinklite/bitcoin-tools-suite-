<?php
class avg_tx_value extends website_tools {

   public static $api = 'https://blockchain.info/q/avgtxvalue';

   public static $settings = array(
      "class"        => __CLASS__,
      "directory"    => __DIR__,
      "name"         => "Average transaction value",
      "description"  => "Average transaction value for the past 1000 blocks",
      "category"     => "Realtime Data",
      "type"     => "info",
      "icon"     => "linear-cart",
      "disabled"     => false
   );


   public static function response() {

         $data = self::http_request(self::$api);

         if ( !$data ) {
            $response['error'] = 'No data was returned from the blockchain api.';
         }
         else {
            
         $response['value'] = $data;

         }
 
      return $response;
   }


}
?>