<?php
class next_retarget extends website_tools {

   public static $api = 'https://blockchain.info/q/nextretarget';

   public static $settings = array(
      "class"        => __CLASS__,
      "directory"    => __DIR__,
      "name"         => "Next Retarget",
      "description"  => "Block height of the next difficulty retarget",
      "category"     => "Realtime Data",
      "type"     => "info",
      "icon"     => "linear-refresh",
      "disabled"     => false
   );


   public static function response() {

         $data = self::http_request(self::$api);

         if ( !$data ) {
            $response['error'] = 'No data was returned from the blockchain api.';
         }
         else {
            
         $response['value'] = $data;

         }
 
      return $response;
   }


}
?>