<?php
class block_reward extends website_tools {

   public static $api = 'https://blockchain.info/q/bcperblock';

   public static $settings = array(
      "class"        => __CLASS__,
      "directory"    => __DIR__,
      "name"         => "Block Reward",
      "description"  => " Current block reward in BTC",
      "category"     => "Realtime Data",
      "type"     => "info",
      "icon"     => "linear-bag-dollar",
      "disabled"     => false
   );


   public static function response() {

         $data = self::http_request(self::$api);

         if ( !$data ) {
            $response['error'] = 'No data was returned from the blockchain api.';
         }
         else {

         $response['value'] = $data;

         }

      return $response;
   }


}
?>
