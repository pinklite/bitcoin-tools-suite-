<?php
class avg_tx_size extends website_tools {

   public static $api = 'https://blockchain.info/q/avgtxsize';

   public static $settings = array(
      "class"        => __CLASS__,
      "directory"    => __DIR__,
      "name"         => "Average transaction size",
      "description"  => "Average transaction size for the past 1000 blocks",
      "category"     => "Realtime Data",
      "type"     => "info",
      "icon"     => "linear-cart-full",
      "disabled"     => false
   );


   public static function response() {

         $data = self::http_request(self::$api);

         if ( !$data ) {
            $response['error'] = 'No data was returned from the blockchain api.';
         }
         else {
            
         $response['value'] = $data;

         }
 
      return $response;
   }


}
?>