<?php
class avg_tx_number extends website_tools {

   public static $api = 'https://blockchain.info/q/avgtxnumber';

   public static $settings = array(
      "class"        => __CLASS__,
      "directory"    => __DIR__,
      "name"         => "Average transaction number",
      "description"  => "Average number of transactions per block",
      "category"     => "Realtime Data",
      "type"     => "info",
      "icon"     => "linear-cart-plus",
      "disabled"     => false
   );


   public static function response() {

         $data = self::http_request(self::$api);

         if ( !$data ) {
            $response['error'] = 'No data was returned from the blockchain api.';
         }
         else {
            
         $response['value'] = $data;

         }
 
      return $response;
   }


}
?>