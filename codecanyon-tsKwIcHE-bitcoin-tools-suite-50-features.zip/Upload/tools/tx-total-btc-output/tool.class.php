<?php
class txtotalbtcoutput extends website_tools {

   public static $api = 'https://blockchain.info/q/txtotalbtcoutput/';


   public static $settings = array(
      "class"        => __CLASS__,
      "directory"    => __DIR__,
      "name"         => "Transaction BTC Output",
      "description"  => "Get total output value of a transaction",
      "category"     => "Transaction Lookups",
      "type"     => "tool",
      "icon"     => "linear-cash-dollar",
      "disabled"     => false
   );


   public static function response($args) {
      if ( !isset($args['query']) || empty($args['query']) ) {
         $response['error'] = 'The input is empty!';
      }
      else if ( strlen($args['query']) < 4 ) {
         $response['error'] = 'The input is too short!';
      }
      else {
         $request = self::$api . $args['query'];
         $data = self::http_request($request);
         if ( !$data ) {
            $response['error'] = 'No response from the blockchain.. check that the information is correct.';
         } elseif ($data == 'exception decoding Hex string: invalid characters encountered in Hex string') {
            $response['error'] = 'Transaction Hash is not valid.';
         }
         else {
         $response['value'] = $data;
           
         }
      }
      return $response;
   }


}
?>