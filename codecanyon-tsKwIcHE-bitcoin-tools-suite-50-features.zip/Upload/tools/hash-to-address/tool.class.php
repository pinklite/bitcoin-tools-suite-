<?php
class hash_to_address extends website_tools {

   public static $api = 'https://blockchain.info/q/hashtoaddress/';


   public static $settings = array(
      "class"        => __CLASS__,
      "directory"    => __DIR__,
      "name"         => "Hash To Address",
      "description"  => "Converts a hash 160 to a bitcoin address",
      "category"     => "Hash Tools",
      "type"     => "tool",
      "icon"     => "linear-tab",
      "disabled"     => false
   );


   public static function response($args) {
      if ( !isset($args['query']) || empty($args['query']) ) {
         $response['error'] = 'The input is empty!';
      }
      else if ( strlen($args['query']) < 4 ) {
         $response['error'] = 'The input is too short!';
      }
      else {
         $request = self::$api . $args['query'];
         $data = self::http_request($request);
         if ( !$data ) {
            $response['error'] = 'No response from the blockchain.. check that the information is correct.';
         } elseif ($data == 'exception decoding Hex string: invalid characters encountered in Hex string') {
            $response['error'] = 'Transaction Hash is not valid.';
         }
         else {
         $response['value'] = $data;
           
         }
      }
      return $response;
   }


}
?>