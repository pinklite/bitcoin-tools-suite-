<?php
class pubkeyaddr extends website_tools {

   public static $api = 'https://blockchain.info/q/pubkeyaddr/';


   public static $settings = array(
      "class"        => __CLASS__,
      "directory"    => __DIR__,
      "name"         => "Address To Pubkey",
      "description"  => "Converts an address to public key (if available)",
      "category"     => "Hash Tools",
      "type"     => "tool",
      "icon"     => "linear-tab",
      "disabled"     => false
   );


   public static function response($args) {
      if ( !isset($args['query']) || empty($args['query']) ) {
         $response['error'] = 'The input is empty!';
      }
      else if ( strlen($args['query']) < 4 ) {
         $response['error'] = 'The input is too short!';
      }
      else {
         $request = self::$api . $args['query'];
         $data = self::http_request($request);
         if ( !$data ) {
            $response['error'] = 'No response from the blockchain.. check that the information is correct.';
         } elseif ($data == 'Checksum does not validate') {
            $response['error'] = 'Address is not a valid bitcoin address.';
         }
         else {
         $response['value'] = $data;
           
         }
      }
      return $response;
   }


}
?>