<ol class="breadcrumb"> <li><a href="<?php echo $website['url']; ?>">Home</a></li> <li><a href="<?php echo $tool['urls']['category'];?>"><?php echo $tool['category'];?></a></li> <li class="active"><?php echo $tool['name'];?></li> </ol>

<div class="tool-page">
   <h2>Convert <?php echo $tool['name'];?></h2>
   <hr>
<?php // if there is an error display it. ?>
<?php if ( $response && isset($response['error']) ):?>
   <div class="alert alert-danger" role="alert"><?php echo $response['error'];?></strong></div>
<?php endif;?>

<?php // if there isn't an error display response. ?>
<?php if ( $response && !isset($response['error']) ):?>
   <div class="alert alert-success" role="alert">The address is <strong><?php echo $response['value'];?></strong></div>
<?php endif;?>

<form method="post" action="<?php echo $tool['urls']['tool'];?>">
   <div class="form-group">
   <input class="form-control input-lg" type="text" name="query" placeholder="Pubkey" />
   </div>
   <button class="btn btn-blue btn-lg" type="submit" name="submit">Lookup</button>
</form>
</div>
