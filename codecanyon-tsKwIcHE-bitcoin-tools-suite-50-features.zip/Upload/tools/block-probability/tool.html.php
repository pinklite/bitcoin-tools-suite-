<ol class="breadcrumb"> <li><a href="<?php echo $website['url']; ?>">Home</a></li> <li><a href="<?php echo $tool['urls']['category'];?>"><?php echo $tool['category'];?></a></li> <li class="active"><?php echo $tool['name'];?></li> </ol>

<div class="tool-page">
   <h2><?php echo $tool['name'];?></h2>
   <hr>
   <?php if ( $response && isset($response['error']) ):?>
      <span><?php echo $response['error'];?></span>
   <?php endif;?>

   <?php if ( $response && !isset($response['error']) ):?>
      <div class="alert alert-warning">The probability is <strong><?php echo number_format($response['value'], 50);?></strong> per hash attempt</div>
   <?php endif;?>
