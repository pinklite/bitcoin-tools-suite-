<?php
class block_probability extends website_tools {

   public static $api = 'https://blockchain.info/q/probability';

   public static $settings = array(
      "class"        => __CLASS__,
      "directory"    => __DIR__,
      "name"         => "Block Probability",
      "description"  => "Probability of finding a valid block each hash attempt",
      "category"     => "Realtime Data",
      "type"     => "info",
      "icon"     => "linear-abacus",
      "disabled"     => false
   );


   public static function response() {

         $data = self::http_request(self::$api);

         if ( !$data ) {
            $response['error'] = 'No data was returned from the blockchain api.';
         }
         else {
            
         $response['value'] = $data;

         }
 
      return $response;
   }


}
?>