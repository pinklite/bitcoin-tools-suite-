<?php
class block_eta extends website_tools {

   public static $api = 'https://blockchain.info/q/eta';

   public static $settings = array(
      "class"        => __CLASS__,
      "directory"    => __DIR__,
      "name"         => "Block Eta",
      "description"  => "Estimated time until the next block (in seconds)",
      "category"     => "Realtime Data",
      "icon"         => "linear-clock3",
      "type"         => "info",
      "disabled"     => false
   );


   public static function response() {

         $data = self::http_request(self::$api);

         if ( !$data ) {
            $response['error'] = 'No data was returned from the blockchain api.';
         }
         else {
            
         $response['value'] = $data;

         }
 
      return $response;
   }


}
?>