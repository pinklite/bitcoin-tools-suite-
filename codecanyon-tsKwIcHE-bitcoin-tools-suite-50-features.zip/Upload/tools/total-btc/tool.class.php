<?php
class total_btc extends website_tools {

   public static $api = 'https://blockchain.info/q/totalbc';

   public static $settings = array(
      "class"        => __CLASS__,
      "directory"    => __DIR__,
      "name"         => "Total BTC",
      "description"  => "Total Bitcoins in circulation (delayed by up to 1 hour)",
      "category"     => "Realtime Data",
      "type"     => "info",
      "icon"     => "linear-vault",
      "disabled"     => false
   );


   public static function response() {

         $data = self::http_request(self::$api);

         if ( !$data ) {
            $response['error'] = 'No data was returned from the blockchain api.';
         }
         else {
            
         $response['value'] = $data;

         }
 
      return $response;
   }


}
?>