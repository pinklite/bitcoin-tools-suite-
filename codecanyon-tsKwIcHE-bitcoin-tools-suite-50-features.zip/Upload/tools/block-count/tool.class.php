<?php
class bock_count extends website_tools {

   public static $api = 'https://blockchain.info/q/getblockcount';

   public static $settings = array(
      "class"        => __CLASS__,
      "directory"    => __DIR__,
      "name"         => "Block Count",
      "description"  => "Current block height in the longest chain",
      "category"     => "Realtime Data",
      "type"     => "info",
      "icon"     => "linear-select",
      "disabled"     => false
   );


   public static function response() {

         $data = self::http_request(self::$api);

         if ( !$data ) {
            $response['error'] = 'No data was returned from the blockchain api.';
         }
         else {

         $response['value'] = $data;

         }

      return $response;
   }


}
?>
