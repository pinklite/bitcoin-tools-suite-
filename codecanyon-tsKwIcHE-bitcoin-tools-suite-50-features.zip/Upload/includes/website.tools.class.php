<?php
class website_tools {


   public static $tools      = array();
   public static $categories = array();


   public static function slug($string) {
      $slug = strtolower($string);
      $slug = preg_replace('/[^a-z0-9]+/', '-', $slug);
      return trim($slug, '-');
   }


   public static function website_protocol() {
      return (isset($_SERVER['HTTPS']) && (!empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http');
   }


   public static function website_url() {
      return self::website_protocol() . '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/';
   }


   public static function website_current() {
      return self::website_protocol() . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
   }


   public static function http_request($url) {
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.91 Safari/537.36');
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
      curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
      $data = curl_exec($ch);
      curl_close($ch);
      return $data;
   }


   public static function register_tool() {
      $classes = get_declared_classes();

      $class   = array_pop($classes);
      if (
         isset($class::$settings)                                       &&
         isset($class::$settings['class'])                              &&
         isset($class::$settings['directory'])                          &&
         isset($class::$settings['name'])                               &&
         isset($class::$settings['description'])                        &&
         isset($class::$settings['category'])                           &&
         isset($class::$settings['type'])                               &&
         isset($class::$settings['icon'])                               &&
         isset($class::$settings['disabled'])                           &&
         method_exists($class, 'response')                              &&
         file_exists($class::$settings['directory'] . '/tool.html.php') &&
         !$class::$settings['disabled']
      ) {
         $slug1 = self::slug($class::$settings['name']);
         $slug2 = self::slug($class::$settings['category']);
         $class::$settings['category'] = strtolower($class::$settings['category']);
         $class::$settings['urls']['tool']      = self::website_url() . 'tool/'      . $slug1;
         $class::$settings['urls']['category']  = self::website_url() . 'categories/' . $slug2;
         $class::$settings['slugs']['tool']     = $slug1;
         $class::$settings['slugs']['category'] = $slug2;
         self::$categories[$slug2]['name']      = $class::$settings['category'];
         self::$categories[$slug2]['url']       = $class::$settings['urls']['category'];
         self::$categories[$slug2]['slug']      = $slug2;
         self::$tools[$slug1]                   = $class::$settings;
      }
   }

    public static function get_bitcoin()
    {
      $raw  = self::http_request('https://cex.io/api/ticker/BTC/USD');
      $data = json_decode($raw, true);
      return $data['last'];
    }

    public static function get_currency()
    {
        $raw  = self::http_request('http://api.fixer.io/latest?base=USD');
        $data = json_decode($raw, true);
        return $data['rates'];
    }
 public static function combine()
    {
        $bvalue = self::get_bitcoin();
        $cvalue = self::get_currency();
        foreach ($cvalue as $k => $v) {
            $value       = $bvalue * $v;
            $bitcoin[$k] = $value;
        }
        $bitcoin['USD'] = $bvalue;
        return $bitcoin;
    }

  public static function cache_json($ctime)
    {
        global $request_type, $purge_cache, $limit_reached, $request_limit;

        $cache_file = dirname(__FILE__) . '/cache/currency.json';
        $expires    = time() - $ctime;

        if (!file_exists($cache_file))
            die("Cache file is missing: $cache_file");

        if (filectime($cache_file) < $expires || file_get_contents($cache_file) == '' || $purge_cache && intval($_SESSION['views']) <= $request_limit) {

            $api_results  = self::combine();
            $json_results = json_encode($api_results);

            if ($api_results && $json_results)
                file_put_contents($cache_file, $json_results);
            else
                unlink($cache_file);
        } else {

            $json_results = file_get_contents($cache_file);
            $request_type = 'JSON';
        }

        return json_decode($json_results);
    }
 public static function satoshi($value) {

  return $value / 100000000;
}

}
?>
