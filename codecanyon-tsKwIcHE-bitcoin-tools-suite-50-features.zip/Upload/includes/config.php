<?php
// path setting constants.
define('PATH_ABSOLUTE', dirname(__FILE__) . '/../');
define('PATH_INCLUDES', PATH_ABSOLUTE . 'includes/');
define('PATH_TOOLS',    PATH_ABSOLUTE . 'tools/');

// require all of the website classes.
require_once(PATH_INCLUDES . 'website.tools.class.php');
foreach ( glob(PATH_TOOLS . '*/tool.class.php') as $class ) {
   require_once($class);
   website_tools::register_tool();
}

// website settings.
$website['name']       = 'Bitcoin Tools Suite';
$website['description']  = 'Bitcoin Tools';
$website['bitcoin_addr']       = '1KVupNqCrxcV66nyWpS4FvWyjWU4gFSHdC';
$website['cache_time']       = '60000';
$website['template']   = 'default';
$website['year']       = date('Y');
$website['tools']      = website_tools::$tools;
$website['categories'] = website_tools::$categories;
$website['url']        = website_tools::website_url();
$website['current']    = website_tools::website_current();

?>
