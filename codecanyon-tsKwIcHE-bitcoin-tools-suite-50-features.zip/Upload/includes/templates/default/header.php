<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?php echo $website['url']; ?>/assets/img/favicon.ico">

    <title><?php echo $meta['title']; ?></title>

    <link href="https://fonts.googleapis.com/css?family=Lato:400,300,700" rel="stylesheet" type="text/css">

    <!-- Linear core CSS -->
    <link href="<?php echo $website['url']; ?>assets/css/linearicons.min.css?t=<?php echo time(); ?>" rel="stylesheet">
    <!-- Bootstrap core CSS -->
    <link href="<?php echo $website['url']; ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Ember core CSS -->
    <link href="<?php echo $website['url']; ?>assets/css/ember.css?t=<?php echo time(); ?>" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
<body>
<nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="<?php echo $website['url']; ?>">
            <img src="<?php echo $website['url']; ?>/assets/img/blogo.png" class="img-responsive" alt="<?php echo $website['name']; ?>"></a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
<?php foreach ( $website['categories'] as $cat ):?>
<li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo ucfirst($cat['name']);?> <span class="caret"></span></a>
              <ul class="dropdown-menu">
<?php foreach ( $website['tools'] as $toolmenu ):?>
                 <?php if($toolmenu['category'] == $cat['name']) { ?>
		      <li><a href="<?php echo $toolmenu['urls']['tool'];?>"><?php echo $toolmenu['name'];?></a></li>
      <?php } endforeach;?>
              </ul>
            </li>
      <?php endforeach;?>
          </ul>
<form class="navbar-form navbar-right">
                  <a href="<?php echo 'bitcoin:' . $website['bitcoin_addr']; ?>" class="btn btn-value">Donate Bitcoin</a>
               </form>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
