<footer>
   <div class="container">
      <div class="row">
         <div class="col-md-4">
         <a href="<?php echo $website['url']; ?>">
            <img src="<?php echo $website['url']; ?>/assets/img/blogo.png" class="img-responsive" alt="<?php echo $website['name']; ?>"></a>
            <p>The most powerful & robust bitcoin tools website. Easily check addresses, convert hashes, generate public keys and more with our wide selection of cryptocurrency related tools. </p>
            <a href="<?php echo 'bitcoin:' . $website['bitcoin_addr']; ?>" class="btn btn-lg btn-hg btn-blue btn-round">Donate</a>
         </div>
         <div class="col-md-8">
            <div class="footer-title">
               <h3>Tools</h3>
            </div>
                        <ul>
                       <?php foreach ( $website['tools'] as $tool ):?>

		      <li><a href="<?php echo $tool['urls']['tool'];?>"><?php echo $tool['name'];?></a></li>
      <?php endforeach;?>
</ul>
                     </div>
      </div>
      <hr>
      <span class="pull-left copyright"><?php echo $website['name']; ?> © 2016-2017 | All rights reserved</span>
      <span class="pull-right"><a href="http://emberthemes.net"><img src="<?php echo $website['url']; ?>/assets/img/logo-dark.png" alt="Built by ember" /></a></span>
   </div>
</footer>




<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo $website['url']; ?>/assets/js/bootstrap.min.js"></script>
</body>
</html>
